<# :
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title AccessFix Custom
set "SELF=%~f0"
set "SAF_ARGS=%*"

:: Tu nang quyen Administrator neu chua co
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [i] Requesting Administrator privileges...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "if ($env:SAF_ARGS) { Start-Process -FilePath $env:SELF -ArgumentList $env:SAF_ARGS -Verb RunAs } else { Start-Process -FilePath $env:SELF -Verb RunAs }"
    exit /b
)

:: Chay phan PowerShell ben duoi file
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Expression ([System.IO.File]::ReadAllText($env:SELF, [System.Text.Encoding]::UTF8))"
exit /b
: end batch / begin powershell #>

#PSBEGIN#
# ================================================================
#  SteamAccessFix v1.2.0 - All-In-One Game & Store Fix (Windows)
#  Pure User-Mode  |  No Drivers  |  Anti-Cheat Safe
#  Tham so dong lenh: /silent (chay ngam) | /install (tu khoi dong) | /uninstall | /stop
# ================================================================

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding  = [System.Text.Encoding]::UTF8
$OutputEncoding           = [System.Text.Encoding]::UTF8

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13
$Host.UI.RawUI.WindowTitle = 'AccessFix Custom (LinkedIn, Quora)'

# Luu tham so dong lenh neu goi truc tiep tu PowerShell
if (-not $env:SAF_ARGS -and $args) { $env:SAF_ARGS = ($args -join ' ') }

function Has-Arg($ten) {
    return ("$env:SAF_ARGS" -match ('(?i)(^|\s)[/-]{1,2}' + [regex]::Escape($ten) + '(\s|$)'))
}

# --- Cau hinh ---
$script:AppVersion  = '1.2.0'
$script:GitHubRepo  = 'vuviett47/SteamAccessFix'
$script:AutoUpdate  = $false
$script:DnsPresets = @(
    @{ Id = 1;  Name = 'Google DNS';        Short = 'Google';     P1 = '8.8.8.8';         P2 = '8.8.4.4' }
    @{ Id = 2;  Name = 'Cloudflare DNS';    Short = 'Cloudflare'; P1 = '1.1.1.1';         P2 = '1.0.0.1' }
    @{ Id = 3;  Name = 'Control D';         Short = 'Control D';  P1 = '76.76.2.0';       P2 = '76.76.10.0' }
    @{ Id = 4;  Name = 'Quad9';             Short = 'Quad9';      P1 = '9.9.9.9';         P2 = '149.112.112.112' }
    @{ Id = 5;  Name = 'OpenDNS (Cisco)';   Short = 'OpenDNS';    P1 = '208.67.222.222';   P2 = '208.67.220.220' }
    @{ Id = 6;  Name = 'AdGuard';           Short = 'AdGuard';    P1 = '94.140.14.14';    P2 = '94.140.15.15' }
    @{ Id = 7;  Name = 'NextDNS';           Short = 'NextDNS';    P1 = '45.90.28.0';      P2 = '45.90.30.0' }
    @{ Id = 8;  Name = 'AliDNS (Alibaba)';  Short = 'AliDNS';     P1 = '223.5.5.5';       P2 = '223.6.6.6' }
    @{ Id = 9;  Name = 'DNS.SB (HongKong)'; Short = 'DNS.SB';     P1 = '185.222.222.222'; P2 = '45.11.45.11' }
    @{ Id = 10; Name = 'Comodo Secure';     Short = 'Comodo';     P1 = '8.26.56.26';      P2 = '8.20.247.20' }
)
$script:DnsMode           = 'Cloudflare'
$script:CurrentDnsName    = 'Cloudflare DNS'
$script:CurrentDnsShort   = 'Cloudflare'
$script:CurrentDnsServers = @('1.1.1.1', '1.0.0.1')
if (Has-Arg 'nodns' -or Has-Arg 'keepdns') {
    $script:DnsMode         = 'Keep'
    $script:CurrentDnsName  = 'Giu nguyen DNS he thong'
    $script:CurrentDnsShort = 'He thong'
}

# Dam bao duong dan SELF luon chinh xac khi chay tu file
if (-not $env:SELF -or -not (Test-Path $env:SELF)) {
    if ($PSCommandPath -and (Test-Path $PSCommandPath)) { $env:SELF = $PSCommandPath }
    elseif ($MyInvocation.MyCommand.Path -and (Test-Path $MyInvocation.MyCommand.Path)) { $env:SELF = $MyInvocation.MyCommand.Path }
}

# Kiem tra quyen Administrator khi chay truc tiep tu PowerShell (irm | iex)
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "`n  [!] Dang yeu cau quyen Administrator..." -ForegroundColor Yellow
    if ($env:SELF -and (Test-Path $env:SELF)) {
        if ($env:SAF_ARGS) {
            Start-Process -FilePath $env:SELF -ArgumentList $env:SAF_ARGS -Verb RunAs
        } else {
            Start-Process -FilePath $env:SELF -Verb RunAs
        }
    } else {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"irm https://gitlab.com/$($script:GitHubRepo)/-/raw/main/SteamAccessFix.cmd | iex`"" -Verb RunAs
    }
    return
}

# --- Duong dan luu tru ---
$ThuMucLuu     = Join-Path $env:ProgramData 'SteamAccessFix'
$FileDns       = Join-Path $ThuMucLuu 'dns-backup.json'
$FileProxy     = Join-Path $ThuMucLuu 'proxy-backup.json'
$FileHosts     = Join-Path $ThuMucLuu 'hosts-backup.txt'
$FileNetTweaks = Join-Path $ThuMucLuu 'net-tweaks-backup.json'
$FileMtu       = Join-Path $ThuMucLuu 'mtu-backup.json'
$FileDnsKeep   = Join-Path $ThuMucLuu 'dns-original-keep.json'
$FileStop      = Join-Path $ThuMucLuu 'stop.flag'
$FileInst      = Join-Path $ThuMucLuu 'instance.txt'
$FileLog       = Join-Path $ThuMucLuu 'silent.log'
$TenTask       = 'SteamAccessFix'
$FileHostsSys  = "$env:SystemRoot\System32\drivers\etc\hosts"
$RegIE         = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
$CongProxy     = 18080

# --- Domain dinh tuyen qua proxy (chi Web/Lobby/GC, UDP tran dau di DIRECT) ---
$AllGameDomains = @(
    'steampowered.com', 'steamcommunity.com', 'steamstatic.com',
    'steam-chat.com', 'steamusercontent.com', 'steamgames.com', 'steamcontent.com', 'steamserver.net',
    'counter-strike.net', 'dota2.com', 'valvesoftware.com',
    'playbattlegrounds.com', 'pubg.com', 'krafton.com', 'pubgapp.com', 'pubgesports.com',
    'narakathegame.com', '24entertainment.net',
    'playdeltaforce.com', 'levelinfinite.com',
    # [Custom] LinkedIn: web chinh, CDN anh/JS/CSS (licdn), link rut gon
    'linkedin.com', 'licdn.com', 'lnkd.in',
    # [Custom] Quora: web chinh + CDN anh/JS (quoracdn)
    'quora.com', 'quoracdn.net'
)
# [Custom] Ten cac web custom hien tren giao dien
$CustomSites = @('LinkedIn', 'Quora')

# --- Trang thai ---
$script:DaThayDoiDns    = $false
$script:DaThayDoiProxy  = $false
$script:DaThayDoiHosts  = $false
$script:DaThayDoiTweaks = $false
$script:DaThayDoiMtu    = $false
$script:CurrentMtu      = 0
$script:Proxy           = $null
$script:CongDangDung    = 0
$script:MoTa            = ''
$script:CurrentLevel    = 0

New-Item -ItemType Directory -Force -Path $ThuMucLuu | Out-Null

# ================================================================
#  GIAO DIEN UI/UX (TIENG VIET KHONG DAU - CHONG LOI FONT 100%)
# ================================================================
function Say($m, $mau = 'Gray') { Write-Host $m -ForegroundColor $mau }
function Ok($m)   { Say "  [OK]   $m" 'Green' }
function Warn($m) { Say "  [!]    $m" 'Yellow' }
function Err($m)  { Say "  [X]    $m" 'Red' }
function Info($m) { Say "  [~]    $m" 'Cyan' }
function Sep()    { Say '  ---------------------------------------------------------------' 'DarkGray' }

function Ve-Khung($tieuDe, $phuDe = '', $mau = 'Cyan') {
    Say ''
    $clean = $tieuDe.Trim()
    if ($clean -notmatch '^\[\>\]') { $clean = "[>] $clean" }
    Say "  $clean" $mau
    Sep
    if ($phuDe) {
        Say "  $($phuDe.Trim())" 'DarkGray'
        Sep
    }
}

# ================================================================
#  MA C# SPLITPROXY NHUNG SAN
# ================================================================
$MaProxy = @'
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

public class FastWebClient : WebClient
{
    public int TimeoutMs = 3000;
    public FastWebClient() {
        this.Proxy = null;
    }
    protected override WebRequest GetWebRequest(Uri uri) {
        WebRequest w = base.GetWebRequest(uri);
        w.Timeout = TimeoutMs;
        w.Proxy = null;
        return w;
    }
}

public class SplitProxy
{
    public int Port;
    public int Mode = 2;
    public int Connections = 0;
    public string Pac = "";
    public bool HasDirect443 = false;
    private TcpListener listenerProxy;
    private TcpListener listenerDirect;
    private TcpListener listenerDirectV6;
    private volatile bool running;
    private byte[] pacBytes;

    public class DnsEntry {
        public List<IPAddress> Ips = new List<IPAddress>();
        public long ExpireTick;
    }
    private static ConcurrentDictionary<string, DnsEntry> dnsCache = new ConcurrentDictionary<string, DnsEntry>();

    // [Custom] Domain luon phan giai qua DoH (Google/Cloudflare) truoc
    public static readonly string[] CustomDohFirst = new string[] {
        "linkedin.com", "licdn.com", "lnkd.in", "quora.com", "quoracdn.net"
    };

    public static readonly string[] PubgDomains = new string[] {
        "prod-live-front.playbattlegrounds.com",
        "prod-live-entry.playbattlegrounds.com",
        "prod-live-xenuine.playbattlegrounds.com",
        "xenuine.playbattlegrounds.com",
        "api.pubg.com",
        "accounts.pubg.com"
    };

    public static void WarmUpPubgCache()
    {
        ThreadPool.QueueUserWorkItem(delegate {
            foreach (var domain in PubgDomains) {
                try { ResolveSafeAll(domain, true); } catch { }
            }
        });
    }

    public static void InvalidateHost(string host, IPAddress failedIp)
    {
        try {
            DnsEntry entry;
            if (dnsCache.TryGetValue(host, out entry) && entry.Ips != null) {
                lock (entry.Ips) {
                    if (entry.Ips.Contains(failedIp)) {
                        entry.Ips.Remove(failedIp);
                        entry.Ips.Add(failedIp);
                    }
                }
            }
        } catch { }
    }

    public static void PromoteWorkingIp(string host, IPAddress workingIp)
    {
        try {
            DnsEntry entry;
            if (dnsCache.TryGetValue(host, out entry) && entry.Ips != null) {
                lock (entry.Ips) {
                    if (entry.Ips.Contains(workingIp) && entry.Ips.Count > 1 && entry.Ips[0] != workingIp) {
                        entry.Ips.Remove(workingIp);
                        entry.Ips.Insert(0, workingIp);
                    }
                }
            }
        } catch { }
    }

    public static void SetTcpKeepAlive(Socket s, uint timeMs = 15000, uint intervalMs = 3000)
    {
        try {
            s.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
            byte[] opt = new byte[12];
            BitConverter.GetBytes((uint)1).CopyTo(opt, 0);
            BitConverter.GetBytes(timeMs).CopyTo(opt, 4);
            BitConverter.GetBytes(intervalMs).CopyTo(opt, 8);
            s.IOControl(IOControlCode.KeepAliveValues, opt, null);
        } catch { }
    }

    private static void ParseJsonIps(string json, List<IPAddress> list)
    {
        if (string.IsNullOrEmpty(json)) return;
        int idx = json.IndexOf("\"data\":\"");
        while (idx > 0) {
            int end = json.IndexOf("\"", idx + 8);
            if (end > idx) {
                string ipStr = json.Substring(idx + 8, end - idx - 8);
                IPAddress parsed;
                if (IPAddress.TryParse(ipStr, out parsed) && !IPAddress.IsLoopback(parsed) && parsed.AddressFamily == AddressFamily.InterNetwork) {
                    if (!list.Contains(parsed)) list.Add(parsed);
                }
            }
            idx = json.IndexOf("\"data\":\"", end);
        }
    }

    public static IPAddress[] ResolveSafeAll(string host, bool forceRefresh = false)
    {
        IPAddress parsedIp;
        if (IPAddress.TryParse(host, out parsedIp)) return new IPAddress[] { parsedIp };

        long now = Environment.TickCount;
        DnsEntry entry = null;
        dnsCache.TryGetValue(host, out entry);
        if (!forceRefresh && entry != null && entry.Ips != null && entry.Ips.Count > 0) {
            if ((now - entry.ExpireTick) < 0) {
                lock (entry.Ips) { return entry.Ips.ToArray(); }
            }
        }

        List<IPAddress> resolvedList = new List<IPAddress>();

        // [Custom] Domain custom: hoi DoH TRUOC, khong tin DNS he thong (tranh nha mang tra IP gia)
        string hl = host.ToLowerInvariant();
        bool dohFirst = false;
        foreach (string cd in CustomDohFirst) {
            if (hl == cd || hl.EndsWith("." + cd)) { dohFirst = true; break; }
        }

        // 1. Thu qua he thong OS DNS (neu host chua bi map 127.0.0.1)
        if (!dohFirst) try {
            IPAddress[] addrs = Dns.GetHostAddresses(host);
            foreach (var a in addrs) {
                if (a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a)) {
                    if (!resolvedList.Contains(a)) resolvedList.Add(a);
                }
            }
        } catch { }

        // 2. Fallback Google DoH
        if (resolvedList.Count == 0) {
            try {
                using (var wc = new FastWebClient()) {
                    wc.TimeoutMs = 3000;
                    wc.Headers[HttpRequestHeader.Accept] = "application/dns-json";
                    string json = wc.DownloadString("https://dns.google/resolve?name=" + host + "&type=A");
                    ParseJsonIps(json, resolvedList);
                }
            } catch { }
        }

        // 3. Fallback Cloudflare DoH
        if (resolvedList.Count == 0) {
            try {
                using (var wc = new FastWebClient()) {
                    wc.TimeoutMs = 3000;
                    wc.Headers[HttpRequestHeader.Accept] = "application/dns-json";
                    string json = wc.DownloadString("https://cloudflare-dns.com/dns-query?name=" + host + "&type=A");
                    ParseJsonIps(json, resolvedList);
                }
            } catch { }
        }

        // [Custom] 4. Domain custom ma DoH deu loi thi moi dung DNS he thong
        if (resolvedList.Count == 0 && dohFirst) {
            try {
                foreach (var a in Dns.GetHostAddresses(host)) {
                    if (a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a) && !resolvedList.Contains(a)) resolvedList.Add(a);
                }
            } catch { }
        }

        if (resolvedList.Count > 0) {
            dnsCache[host] = new DnsEntry { Ips = resolvedList, ExpireTick = now + 900000 };
            return resolvedList.ToArray();
        }

        // Neu moi kenh deu loi, tra ve cache cu neu co de cuu ket noi PUBG
        if (entry != null && entry.Ips != null && entry.Ips.Count > 0) {
            lock (entry.Ips) { return entry.Ips.ToArray(); }
        }
        return new IPAddress[0];
    }

    public static IPAddress ResolveSafe(string host)
    {
        IPAddress[] ips = ResolveSafeAll(host);
        return (ips.Length > 0) ? ips[0] : null;
    }

    public SplitProxy(int port) {
        Port = port;
        try { ServicePointManager.DefaultConnectionLimit = 512; } catch { }
    }

    public void Start()
    {
        pacBytes = Encoding.UTF8.GetBytes(Pac == null ? "" : Pac);
        running = true;
        WarmUpPubgCache();

        listenerProxy = new TcpListener(IPAddress.Loopback, Port);
        listenerProxy.Start();
        Thread tProxy = new Thread(new ThreadStart(AcceptLoopProxy));
        tProxy.IsBackground = true;
        tProxy.Start();

        try {
            listenerDirect = new TcpListener(IPAddress.Loopback, 443);
            try { listenerDirect.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true); } catch { }
            listenerDirect.Start();
            HasDirect443 = true;
            Thread tDirect = new Thread(new ThreadStart(AcceptLoopDirect));
            tDirect.IsBackground = true;
            tDirect.Start();
        } catch {
            HasDirect443 = false;
        }

        try {
            if (Socket.OSSupportsIPv6) {
                listenerDirectV6 = new TcpListener(IPAddress.IPv6Loopback, 443);
                try { listenerDirectV6.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true); } catch { }
                listenerDirectV6.Start();
                Thread tDirectV6 = new Thread(new ThreadStart(AcceptLoopDirectV6));
                tDirectV6.IsBackground = true;
                tDirectV6.Start();
            }
        } catch { }
    }

    public void Stop()
    {
        running = false;
        try { if (listenerProxy != null) listenerProxy.Stop(); } catch { }
        try { if (listenerDirect != null) listenerDirect.Stop(); } catch { }
        try { if (listenerDirectV6 != null) listenerDirectV6.Stop(); } catch { }
    }

    private void AcceptLoopProxy()
    {
        while (running)
        {
            try { TcpClient c = listenerProxy.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(new WaitCallback(HandleProxy), c); }
            catch (Exception) { if (!running) return; }
        }
    }

    private void AcceptLoopDirect()
    {
        while (running)
        {
            try { TcpClient c = listenerDirect.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(new WaitCallback(HandleDirect), c); }
            catch (Exception) { if (!running) return; }
        }
    }

    private void AcceptLoopDirectV6()
    {
        while (running)
        {
            try { TcpClient c = listenerDirectV6.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(new WaitCallback(HandleDirect), c); }
            catch (Exception) { if (!running) return; }
        }
    }

    private static int HeaderEnd(byte[] b, int len)
    {
        for (int i = 0; i + 3 < len; i++)
            if (b[i] == 13 && b[i + 1] == 10 && b[i + 2] == 13 && b[i + 3] == 10) return i;
        return -1;
    }

    private static void SplitHostPort(string hp, out string host, out int port)
    {
        port = 443;
        int idx = hp.LastIndexOf(':');
        if (hp.StartsWith("[")) {
            int close = hp.IndexOf(']');
            if (close > 1) {
                host = hp.Substring(1, close - 1);
                if (idx > close && idx + 1 < hp.Length) int.TryParse(hp.Substring(idx + 1), out port);
                return;
            }
        }
        if (idx > 0 && idx + 1 < hp.Length) { host = hp.Substring(0, idx); int.TryParse(hp.Substring(idx + 1), out port); }
        else host = hp;
    }

    private static int FindSni(byte[] d, int len, out string sniHost, out int nameLen)
    {
        sniHost = null; nameLen = 0;
        try {
            if (len < 43 || d[0] != 0x16 || d[5] != 0x01) return -1;
            int p = 5 + 4 + 2 + 32;
            p += 1 + d[p];
            p += 2 + ((d[p] << 8) | d[p + 1]);
            p += 1 + d[p];
            int extEnd = p + 2 + ((d[p] << 8) | d[p + 1]);
            p += 2;
            while (p + 4 <= extEnd && p + 4 <= len) {
                int type = (d[p] << 8) | d[p + 1];
                int el   = (d[p + 2] << 8) | d[p + 3];
                if (type == 0) {
                    int q = p + 4 + 2 + 1;
                    nameLen = (d[q] << 8) | d[q + 1];
                    if (q + 2 + nameLen <= len) {
                        sniHost = Encoding.ASCII.GetString(d, q + 2, nameLen);
                    }
                    return q + 2;
                }
                p += 4 + el;
            }
        } catch { }
        return -1;
    }

    private void SendSplit(NetworkStream ss, byte[] d, int len, int mode)
    {
        string sniHost; int nameLen;
        int sni   = FindSni(d, len, out sniHost, out nameLen);
        // [Custom] Web custom: cat them 1 nhat o GIUA ten mien (SNI) de DPI khong doc duoc ten
        if (!string.IsNullOrEmpty(sniHost)) {
            string sh = sniHost.ToLowerInvariant();
            foreach (string cd in CustomDohFirst) {
                if (sh == cd || sh.EndsWith("." + cd)) { mode = 3; break; }
            }
        }
        int mid   = (sni > 0 && nameLen > 1) ? sni + nameLen / 2 : 1;
        int first = (sni > 0) ? sni + 1 : 1;
        int[] cuts;
        if      (mode == 2) cuts = new int[] { 1 };
        else if (mode == 3) cuts = new int[] { 1, mid };
        else if (mode == 4) cuts = new int[] { first };
        else                cuts = new int[] { mid };
        int pos = 0;
        foreach (int c in cuts) {
            if (c <= pos || c >= len) continue;
            ss.Write(d, pos, c - pos); ss.Flush();
            Thread.Sleep(20);
            pos = c;
        }
        ss.Write(d, pos, len - pos); ss.Flush();
    }

    private static void Pump(Stream from, Stream to, TcpClient a, TcpClient b)
    {
        byte[] buf = new byte[32768];
        try {
            int n;
            while ((n = from.Read(buf, 0, buf.Length)) > 0) {
                to.Write(buf, 0, n);
            }
        } catch { }
        try { if (b.Connected) b.Client.Shutdown(SocketShutdown.Send); } catch { }
    }

    private void HandleDirect(object state)
    {
        TcpClient client = (TcpClient)state;
        TcpClient server = null;
        string sniHost = null;
        IPAddress connectedIp = null;
        try {
            client.NoDelay = true;
            SetTcpKeepAlive(client.Client, 15000, 3000);
            client.ReceiveTimeout = 15000;
            NetworkStream cs = client.GetStream();
            byte[] first = new byte[16384];
            int fl = cs.Read(first, 0, first.Length);
            if (fl <= 0) return;

            // DOC TOAN BO TLS Record truoc khi FindSni de khong bi cat ngang boi TCP MSS (1460 bytes)
            if (first[0] == 0x16 && fl >= 5) {
                int need = 5 + ((first[3] << 8) | first[4]);
                while (fl < need && fl < first.Length) {
                    int n2 = cs.Read(first, fl, first.Length - fl);
                    if (n2 <= 0) break;
                    fl += n2;
                }
            }

            int nameLen;
            int sniPos = FindSni(first, fl, out sniHost, out nameLen);
            if (string.IsNullOrEmpty(sniHost)) {
                sniHost = "prod-live-front.playbattlegrounds.com";
            }

            IPAddress[] targetIps = ResolveSafeAll(sniHost);
            if (targetIps.Length == 0) return;

            // Thu ket noi da IP (Happy Eyeballs / Failover) voi timeout 3.5s moi IP
            foreach (var ip in targetIps) {
                try {
                    server = new TcpClient();
                    server.NoDelay = true;
                    SetTcpKeepAlive(server.Client, 15000, 3000);
                    IAsyncResult ar = server.BeginConnect(ip, 443, null, null);
                    if (ar.AsyncWaitHandle.WaitOne(3500, false)) {
                        server.EndConnect(ar);
                        connectedIp = ip;
                        break;
                    } else {
                        server.Close();
                        InvalidateHost(sniHost, ip);
                    }
                } catch {
                    try { server.Close(); } catch { }
                    InvalidateHost(sniHost, ip);
                }
            }

            if (connectedIp == null || server == null || !server.Connected) return;
            PromoteWorkingIp(sniHost, connectedIp);

            NetworkStream ss = server.GetStream();
            if (first[0] == 0x16 && fl >= 5) {
                SendSplit(ss, first, fl, Mode);
            } else {
                ss.Write(first, 0, fl);
            }
            client.ReceiveTimeout = 0;

            TcpClient sv = server, cl = client;
            Thread t = new Thread(delegate() { Pump(ss, cs, sv, cl); });
            t.IsBackground = true; t.Start();
            Pump(cs, ss, cl, sv);
            try { t.Join(5000); } catch { }
        } catch { }
        finally {
            try { client.Close(); } catch { }
            try { if (server != null) server.Close(); } catch { }
        }
    }

    private void HandleProxy(object state)
    {
        TcpClient client = (TcpClient)state;
        TcpClient server = null;
        try {
            client.NoDelay = true;
            try { client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true); } catch { }
            client.ReceiveTimeout = 15000;
            NetworkStream cs = client.GetStream();
            byte[] buf = new byte[16384];
            int len = 0, he = -1;
            while (he < 0) {
                if (len >= buf.Length) return;
                int n = cs.Read(buf, len, buf.Length - len);
                if (n <= 0) return;
                len += n;
                he = HeaderEnd(buf, len);
            }
            string head    = Encoding.ASCII.GetString(buf, 0, he);
            string line    = head.Split('\n')[0].Trim();
            string[] parts = line.Split(' ');
            if (parts.Length < 2) return;
            string method  = parts[0].ToUpperInvariant();

            if (method == "GET" && parts[1].StartsWith("/proxy.pac")) {
                string h = "HTTP/1.1 200 OK\r\nContent-Type: application/x-ns-proxy-autoconfig\r\nContent-Length: " + pacBytes.Length + "\r\nConnection: close\r\n\r\n";
                byte[] hb = Encoding.ASCII.GetBytes(h);
                cs.Write(hb, 0, hb.Length);
                cs.Write(pacBytes, 0, pacBytes.Length);
                return;
            }

            if (method != "CONNECT") {
                string targetHost = "";
                int targetPort = 80;
                Uri uri;
                if (Uri.TryCreate(parts[1], UriKind.Absolute, out uri)) {
                    targetHost = uri.Host;
                    targetPort = uri.Port;
                } else {
                    int hi = head.IndexOf("Host: ", StringComparison.OrdinalIgnoreCase);
                    if (hi >= 0) {
                        int he2 = head.IndexOf("\r\n", hi);
                        string hp = (he2 > hi) ? head.Substring(hi + 6, he2 - (hi + 6)).Trim() : head.Substring(hi + 6).Trim();
                        SplitHostPort(hp, out targetHost, out targetPort);
                        if (targetPort == 443) targetPort = 80;
                    }
                }
                if (string.IsNullOrEmpty(targetHost)) return;

                IPAddress targetIp = ResolveSafe(targetHost);
                server = new TcpClient();
                server.NoDelay = true;
                try { server.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true); } catch { }

                IAsyncResult ar = (targetIp != null) ? server.BeginConnect(targetIp, targetPort, null, null) : server.BeginConnect(targetHost, targetPort, null, null);
                if (!ar.AsyncWaitHandle.WaitOne(15000, false)) { server.Close(); return; }
                server.EndConnect(ar);

                NetworkStream ss = server.GetStream();
                ss.Write(buf, 0, len); ss.Flush();

                TcpClient sv = server, cl = client;
                Thread t = new Thread(delegate() { Pump(ss, cs, sv, cl); });
                t.IsBackground = true; t.Start();
                Pump(cs, ss, cl, sv);
                try { t.Join(5000); } catch { }
                return;
            }

            string host; int port;
            SplitHostPort(parts[1], out host, out port);
            IPAddress targetIpConnect = ResolveSafe(host);

            server = new TcpClient();
            server.NoDelay = true;
            SetTcpKeepAlive(server.Client, 15000, 3000);

            IAsyncResult arConnect = (targetIpConnect != null) ? server.BeginConnect(targetIpConnect, port, null, null) : server.BeginConnect(host, port, null, null);
            if (!arConnect.AsyncWaitHandle.WaitOne(15000, false)) {
                server.Close();
                return;
            }
            server.EndConnect(arConnect);

            byte[] ok = Encoding.ASCII.GetBytes("HTTP/1.1 200 Connection Established\r\n\r\n");
            cs.Write(ok, 0, ok.Length);
            Interlocked.Increment(ref Connections);

            NetworkStream ssConnect = server.GetStream();
            byte[] first = new byte[16384];
            client.ReceiveTimeout = 15000;
            int fl = cs.Read(first, 0, first.Length);
            if (fl <= 0) return;
            if (first[0] == 0x16 && fl >= 5) {
                int need = 5 + ((first[3] << 8) | first[4]);
                while (fl < need && fl < first.Length) { int n2 = cs.Read(first, fl, first.Length - fl); if (n2 <= 0) break; fl += n2; }
                SendSplit(ssConnect, first, fl, Mode);
            } else ssConnect.Write(first, 0, fl);
            client.ReceiveTimeout = 0;

            TcpClient svConnect = server, clConnect = client;
            Thread tConnect = new Thread(delegate() { Pump(ssConnect, cs, svConnect, clConnect); });
            tConnect.IsBackground = true; tConnect.Start();
            Pump(cs, ssConnect, clConnect, svConnect);
            try { tConnect.Join(5000); } catch { }
        } catch (Exception) { }
        finally {
            try { client.Close(); } catch { }
            try { if (server != null) server.Close(); } catch { }
        }
    }
}

public class ConsoleHelper
{
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetStdHandle(int nStdHandle);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

    [DllImport("wininet.dll", SetLastError = true)]
    public static extern bool InternetSetOption(IntPtr h, int o, IntPtr b, int l);

    [DllImport("dnsapi.dll", EntryPoint = "DnsFlushResolverCache")]
    public static extern int DnsFlushResolverCache();

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    public static void HideConsole()
    {
        try {
            IntPtr h = GetConsoleWindow();
            if (h != IntPtr.Zero) ShowWindow(h, 0);
        } catch { }
    }

    public static void ShowConsole()
    {
        try {
            IntPtr h = GetConsoleWindow();
            if (h != IntPtr.Zero) {
                ShowWindow(h, 9);
                SetForegroundWindow(h);
            }
        } catch { }
    }

    public static void DisableQuickEdit()
    {
        try {
            IntPtr h = GetStdHandle(-10); // STD_INPUT_HANDLE = -10
            uint mode;
            if (GetConsoleMode(h, out mode)) {
                mode &= ~0x0040u; // disable ENABLE_QUICK_EDIT_MODE (0x0040)
                mode |= 0x0080u;  // enable ENABLE_EXTENDED_FLAGS (0x0080)
                SetConsoleMode(h, mode);
            }
        } catch { }
    }
}

public class NativeCleanup
{
    private delegate bool ConsoleCtrlDelegate(int sig);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetConsoleCtrlHandler(ConsoleCtrlDelegate handler, bool add);

    private static ConsoleCtrlDelegate handler;
    public static volatile bool IsActive = false;

    public static void Register()
    {
        if (handler == null) {
            handler = new ConsoleCtrlDelegate(HandlerRoutine);
            SetConsoleCtrlHandler(handler, true);
        }
    }

    public static void Unregister()
    {
        if (handler != null) {
            SetConsoleCtrlHandler(handler, false);
            handler = null;
        }
    }

    private static bool HandlerRoutine(int sig)
    {
        if (IsActive) {
            try {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true)) {
                    if (k != null) {
                        k.DeleteValue("AutoConfigURL", false);
                        k.SetValue("ProxyEnable", 0, RegistryValueKind.DWord);
                        k.DeleteValue("ProxyServer", false);
                    }
                }
                ConsoleHelper.InternetSetOption(IntPtr.Zero, 39, IntPtr.Zero, 0);
                ConsoleHelper.InternetSetOption(IntPtr.Zero, 37, IntPtr.Zero, 0);
            } catch { }

            try {
                string progData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SteamAccessFix");
                string inst = Path.Combine(progData, "instance.txt");
                if (File.Exists(inst)) File.Delete(inst);
            } catch { }

            try {
                string hosts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"drivers\etc\hosts");
                if (File.Exists(hosts)) {
                    var lines = File.ReadAllLines(hosts);
                    bool hasSaf = false;
                    var clean = new List<string>();
                    foreach (var l in lines) {
                        if (l.IndexOf("# SteamAccessFix", StringComparison.OrdinalIgnoreCase) >= 0) {
                            hasSaf = true;
                        } else {
                            clean.Add(l);
                        }
                    }
                    if (hasSaf) {
                        var attr = File.GetAttributes(hosts);
                        bool isRo = (attr & FileAttributes.ReadOnly) != 0;
                        if (isRo) File.SetAttributes(hosts, attr & ~FileAttributes.ReadOnly);
                        File.WriteAllLines(hosts, clean.ToArray());
                        if (isRo) File.SetAttributes(hosts, attr);
                    }
                }
            } catch { }
        }
        return false;
    }
}

public class MtuFinder
{
    public static int FindBestMtu(string target = "8.8.8.8")
    {
        IPAddress ip;
        if (!IPAddress.TryParse(target, out ip)) ip = IPAddress.Parse("8.8.8.8");

        using (var p = new Ping())
        {
            var options = new PingOptions { DontFragment = true, Ttl = 64 };
            byte[] buf1472 = new byte[1472];

            try {
                var reply = p.Send(ip, 500, buf1472, options);
                if (reply != null && reply.Status == IPStatus.Success) return 1500;
            } catch { }

            int low = 1360;
            int high = 1472;
            int bestPayload = -1;

            while (low <= high)
            {
                int mid = (low + high) / 2;
                byte[] testBuf = new byte[mid];
                try {
                    var reply = p.Send(ip, 450, testBuf, options);
                    if (reply != null && reply.Status == IPStatus.Success) {
                        bestPayload = mid;
                        low = mid + 1;
                    } else {
                        high = mid - 1;
                    }
                } catch {
                    high = mid - 1;
                }
            }

            if (bestPayload > 0) return bestPayload + 28;
            return 1492;
        }
    }
}

public class GameWatcher
{
    private static Thread watcherThread;
    private static volatile bool isRunning = false;
    private static HashSet<string> knownProcesses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    private static readonly string[] targetGames = new string[] {
        "tslgame", "steam", "cs2", "dota2", "narakabladepoint", "deltaforce"
    };

    public static volatile string LastTriggeredGame = null;

    public static void Start()
    {
        if (isRunning) return;
        isRunning = true;

        try {
            foreach (var p in Process.GetProcesses()) {
                try { knownProcesses.Add(p.ProcessName); } catch { }
            }
        } catch { }

        watcherThread = new Thread(() => {
            while (isRunning) {
                try {
                    Thread.Sleep(2500);
                    if (!isRunning) break;

                    var current = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var p in Process.GetProcesses()) {
                        try { current.Add(p.ProcessName); } catch { }
                    }

                    foreach (var game in targetGames) {
                        if (current.Contains(game) && !knownProcesses.Contains(game)) {
                            if (!game.Equals("tslgame", StringComparison.OrdinalIgnoreCase)) {
                                ConsoleHelper.DnsFlushResolverCache();
                            } else {
                                SplitProxy.WarmUpPubgCache();
                            }
                            LastTriggeredGame = game;
                        }
                    }
                    knownProcesses = current;
                } catch { }
            }
        });
        watcherThread.IsBackground = true;
        watcherThread.Start();
    }

    public static void Stop()
    {
        isRunning = false;
    }
}

public class FastUpdater
{
    public static volatile string RemoteVersion = null;
    public static volatile bool IsChecked = false;

    public static void CheckAsync(string repo)
    {
        if (string.IsNullOrEmpty(repo) || repo == "USERNAME/REPOSITORY") return;
        ThreadPool.QueueUserWorkItem(_ => {
            try {
                long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                string[] urls = new string[] {
                    "https://gitlab.com/" + repo + "/-/raw/main/VERSION.txt?t=" + now,
                    "https://raw.githubusercontent.com/" + repo + "/main/VERSION.txt?t=" + now
                };
                foreach (var url in urls) {
                    try {
                        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                        req.Timeout = 2500;
                        req.ReadWriteTimeout = 2500;
                        req.Proxy = null;
                        req.Method = "GET";
                        using (HttpWebResponse res = (HttpWebResponse)req.GetResponse()) {
                            if (res.StatusCode == HttpStatusCode.OK) {
                                using (StreamReader r = new StreamReader(res.GetResponseStream())) {
                                    RemoteVersion = r.ReadToEnd().Trim();
                                    break;
                                }
                            }
                        }
                    } catch { }
                    if (!string.IsNullOrEmpty(RemoteVersion)) break;
                }
            } catch { }
            IsChecked = true;
        });
    }
}

public class DnsPinger
{
    public class Result {
        public int Id;
        public string Name;
        public string ShortName;
        public string Primary;
        public string Secondary;
        public long PingMs;
    }

    public static List<Result> TestAll(string[] data) {
        var results = new ConcurrentBag<Result>();
        var tasks = new List<Task>();

        foreach (var item in data) {
            var parts = item.Split('|');
            if (parts.Length < 5) continue;
            int id = int.Parse(parts[0]);
            string name = parts[1];
            string shortName = parts[2];
            string p1 = parts[3];
            string p2 = parts[4];

            tasks.Add(Task.Run(() => {
                long ping = -1;
                try {
                    IPAddress ip;
                    if (IPAddress.TryParse(p1, out ip)) {
                        using (var p = new Ping()) {
                            var reply = p.Send(ip, 1000);
                            if (reply.Status == IPStatus.Success) {
                                ping = reply.RoundtripTime;
                            }
                        }
                    }
                } catch { }
                results.Add(new Result { Id = id, Name = name, ShortName = shortName, Primary = p1, Secondary = p2, PingMs = ping });
            }));
        }

        Task.WaitAll(tasks.ToArray());
        var list = new List<Result>(results);
        list.Sort((a, b) => a.Id.CompareTo(b.Id));
        return list;
    }
}
'@

# ================================================================
#  QUAN LY DNS
# ================================================================
function Split-Ns($v) {
    if (-not $v) { return @() }
    $items = if ($v -is [System.Collections.IEnumerable] -and -not ($v -is [string])) { $v } else { @($v) }
    $out = @()
    foreach ($item in $items) {
        if (-not $item) { continue }
        $parts = [string]$item -split '[,;\s]+'
        foreach ($p in $parts) {
            $t = $p.Trim()
            if ($t -and [System.Net.IPAddress]::TryParse($t, [ref]$null)) {
                $out += $t
            }
        }
    }
    return @($out | Select-Object -Unique)
}

# Doc danh sach DNS dang cau hinh tay (registry NameServer = chuoi phan cach bang dau phay/khoang trang)
function Get-NsReg($guid, [int]$fam = 4) {
    if ($fam -eq 6) { $k = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\$guid" }
    else            { $k = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$guid" }
    $p = Get-ItemProperty $k -EA SilentlyContinue
    if (-not $p) { return @() }
    return @(Split-Ns $p.NameServer)
}

$script:CachedAdapters = $null
function Get-ActiveAdapters {
    if ($null -eq $script:CachedAdapters -or $script:CachedAdapters.Count -eq 0) {
        $adapters = @(Get-NetAdapter -Physical -EA SilentlyContinue | Where-Object Status -eq 'Up')
        if ($adapters.Count -eq 0) { $adapters = @(Get-NetAdapter -EA SilentlyContinue | Where-Object Status -eq 'Up') }
        if ($adapters.Count -eq 0) { $adapters = @(Get-NetAdapter -EA SilentlyContinue) }
        $script:CachedAdapters = $adapters
    }
    return $script:CachedAdapters
}

function Flush-DnsCache {
    try { [ConsoleHelper]::DnsFlushResolverCache() | Out-Null }
    catch { ipconfig /flushdns 2>&1 | Out-Null }
}

function Get-AdapterIsStatic($idx) {
    try { return ((Get-NetIPInterface -InterfaceIndex $idx -AddressFamily IPv4 -EA Stop).Dhcp -eq 'Disabled') } catch { return $false }
}

function Save-Dns {
    if (Test-Path $FileDns) { return }
    $adapters = Get-ActiveAdapters
    $ds = foreach ($a in $adapters) {
        [pscustomobject]@{
            Index    = $a.ifIndex
            Guid     = $a.InterfaceGuid
            Name     = $a.Name
            IsStatic = (Get-AdapterIsStatic $a.ifIndex)
            NS4      = @(Get-NsReg $a.InterfaceGuid 4)
            NS6      = @(Get-NsReg $a.InterfaceGuid 6)
        }
    }
    @($ds) | ConvertTo-Json -Depth 4 | Set-Content -Path $FileDns -Encoding ASCII
}

# Dat DNS an toan: khong bao gio reset ve trong truoc, ho tro fallback netsh chuan. Tra ve $true/$false
function Set-DnsSafe($nic, [string[]]$v4, [string[]]$v6) {
    $idx      = $nic.ifIndex
    $guid     = $nic.InterfaceGuid
    $v4       = @(Split-Ns $v4)
    $v6       = @(Split-Ns $v6)
    $all      = @($v4) + @($v6)
    $isStatic = (Get-AdapterIsStatic $idx)

    # 1. Truong hop khong co DNS thu cong (DHCP hoac trong)
    if ($all.Count -eq 0) {
        if ($isStatic) {
            # Card mang IP tinh thi TUYET DOI khong duoc de DNS trong (se mat mang ngay lap tuc)
            # Lay gateway lam DNS, kem them 8.8.8.8
            $gw = (Get-NetRoute -InterfaceIndex $idx -DestinationPrefix '0.0.0.0/0' -EA SilentlyContinue | Select-Object -First 1).NextHop
            if (-not $gw -or $gw -eq '0.0.0.0') {
                $regGw = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$guid" -EA SilentlyContinue).DefaultGateway
                if ($regGw) { $gw = @($regGw)[0] }
            }
            $list = @()
            if ($gw -and $gw -ne '0.0.0.0') { $list += $gw }
            $list += '8.8.8.8'
            $v4 = @(Split-Ns $list)
            $all = $v4
        } else {
            # Card DHCP: reset ve che do tu dong nhan tu Router
            try { Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -EA Stop | Out-Null } catch { }
            try { netsh interface ipv4 set dnsservers name="$idx" source=dhcp 2>&1 | Out-Null } catch { }
            return $true
        }
    }

    # 2. Dat DNS: gan thang gia tri moi (khong reset ve trong truoc de tranh rot mang)
    $success = $false
    try {
        Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses $all -EA Stop | Out-Null
        $success = $true
    } catch { }

    # Neu loi (co the do IPv6 khong duoc ho tro tren card), thu dat rieng IPv4
    if (-not $success -and $v4.Count -gt 0) {
        try {
            Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses $v4 -EA Stop | Out-Null
            $success = $true
        } catch { }
    }

    # Kiem tra lai registry
    $want = $v4 -join ','
    $curReg = @(Get-NsReg $guid 4)
    if (($curReg -join ',') -ne $want -and $v4.Count -gt 0) {
        # Fallback netsh: dung cu phap chuan Microsoft (set source=static truoc, add dnsservers sau)
        netsh interface ipv4 set dnsservers name="$idx" source=static address=$($v4[0]) validate=no 2>&1 | Out-Null
        for ($i = 1; $i -lt $v4.Count; $i++) {
            netsh interface ipv4 add dnsservers name="$idx" address=$($v4[$i]) index=($i + 1) validate=no 2>&1 | Out-Null
        }
        $curReg = @(Get-NsReg $guid 4)
    }

    return (($curReg -join ',') -eq $want)
}

# Luoi an toan: card mang IP tinh ma DNS bi trong => dat DNS du phong (Gateway + 8.8.8.8) de khong mat mang
function Ensure-StaticDns {
    $adapters = Get-ActiveAdapters
    foreach ($a in $adapters) {
        if (-not (Get-AdapterIsStatic $a.ifIndex)) { continue }
        if (@(Get-NsReg $a.InterfaceGuid 4).Count -gt 0) { continue }
        $gw = (Get-NetRoute -InterfaceIndex $a.ifIndex -DestinationPrefix '0.0.0.0/0' -EA SilentlyContinue | Select-Object -First 1).NextHop
        if (-not $gw -or $gw -eq '0.0.0.0') {
            $regGw = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($a.InterfaceGuid)" -EA SilentlyContinue).DefaultGateway
            if ($regGw) { $gw = @($regGw)[0] }
        }
        $list = @()
        if ($gw -and $gw -ne '0.0.0.0') { $list += $gw }
        $list += '8.8.8.8'
        Warn "[$($a.Name)] IP tinh nhung DNS dang trong -> dat DNS du phong de khong mat mang."
        [void](Set-DnsSafe $a $list @())
    }
}

function Show-Dns {
    $adapters = Get-ActiveAdapters
    foreach ($a in $adapters) {
        $d = @(Get-NsReg $a.InterfaceGuid 4)
        if ($d.Count -gt 0) { $t = $d -join ', ' } else { $t = '(tu dong - DHCP)' }
        Say "  [~]    DNS hien tai [$($a.Name)]: $t" 'DarkGray'
    }
}

function Restore-Dns([string]$src = $FileDns) {
    $allOk = $true
    if (Test-Path $src) {
        try {
            # Gan vao bien truoc: ConvertFrom-Json (PS 5.1) tra mang nguyen khoi, can @($json) de tach tung card
            $json = Get-Content $src -Raw -EA Stop | ConvertFrom-Json
            foreach ($a in @($json)) {
                $nic = $null
                if ($a.Guid) { $nic = Get-NetAdapter -EA SilentlyContinue | Where-Object { $_.InterfaceGuid -eq $a.Guid } | Select-Object -First 1 }
                if (-not $nic -and $null -ne $a.Index) { $nic = Get-NetAdapter -InterfaceIndex $a.Index -EA SilentlyContinue }
                if (-not $nic) { continue }

                # Tuong thich moi format (chuoi, mang, v1.1.4, v1.1.5)
                $v4 = @(Split-Ns $a.NS4)
                $v6 = @(Split-Ns $a.NS6)
                $isStatic = if ($null -ne $a.IsStatic) { [bool]$a.IsStatic } else { (Get-AdapterIsStatic $nic.ifIndex) }

                if ($v4.Count -eq 0 -and $v6.Count -eq 0) {
                    if ($isStatic) {
                        # Card IP tinh nhung DNS goc trong -> dat gateway + 8.8.8.8 de khong mat mang
                        $gw = (Get-NetRoute -InterfaceIndex $nic.ifIndex -DestinationPrefix '0.0.0.0/0' -EA SilentlyContinue | Select-Object -First 1).NextHop
                        if (-not $gw -or $gw -eq '0.0.0.0') {
                            $regGw = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($nic.InterfaceGuid)" -EA SilentlyContinue).DefaultGateway
                            if ($regGw) { $gw = @($regGw)[0] }
                        }
                        $list = @()
                        if ($gw -and $gw -ne '0.0.0.0') { $list += $gw }
                        $list += '8.8.8.8'
                        if (-not (Set-DnsSafe $nic $list @())) { $allOk = $false }
                    } else {
                        Set-DnsClientServerAddress -InterfaceIndex $nic.ifIndex -ResetServerAddresses -EA SilentlyContinue | Out-Null
                    }
                } elseif (-not (Set-DnsSafe $nic $v4 $v6)) {
                    $allOk = $false
                    Warn "Khong khoi phuc duoc DNS goc cua [$($nic.Name)] - tam dat DNS du phong."
                    [void](Set-DnsSafe $nic @('8.8.8.8', '8.8.4.4') @())
                }
            }
        } catch { $allOk = $false }

        # Chi xoa backup khi khoi phuc thanh cong -> giu lai neu loi de lan sau con thu lai
        if ($allOk) { Remove-Item $src -Force -EA SilentlyContinue }
    }
    Ensure-StaticDns
    Flush-DnsCache
    $script:DaThayDoiDns = $false
}

function Set-CustomDns($name, $short, [string[]]$servers) {
    Save-Dns
    $script:DaThayDoiDns      = $true
    $script:DnsMode           = $short
    $script:CurrentDnsName    = $name
    $script:CurrentDnsShort   = $short
    $script:CurrentDnsServers = $servers

    $adapters = Get-ActiveAdapters
    $allOk = $true
    foreach ($a in $adapters) {
        $r = Set-DnsSafe $a $servers @()
        if (-not $r) { $allOk = $false }
    }
    Flush-DnsCache
    return $allOk
}

function Set-GoogleDns {
    # [Custom] Mac dinh dung Cloudflare (ten ham giu nguyen de khong vo cho khac)
    return (Set-CustomDns 'Cloudflare DNS' 'Cloudflare' @('1.1.1.1', '1.0.0.1'))
}

# ================================================================
#  QUAN LY PROXY (PAC + SplitProxy)
# ================================================================
function Notify-Inet {
    try {
        [ConsoleHelper]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0) | Out-Null
        [ConsoleHelper]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0) | Out-Null
    } catch { }
}

function Save-ProxyCfg {
    if (Test-Path $FileProxy) { return }
    $cu = Get-ItemProperty $RegIE -EA SilentlyContinue
    $proxyServer = $cu.ProxyServer
    $autoConfig  = $cu.AutoConfigURL
    $proxyEnable = $cu.ProxyEnable

    # Loc sach neu registry dang bi ton dong proxy tu phien cu (v1.1.3 tro ve truoc)
    if ($proxyServer -match '127\.0\.0\.1|localhost' -or $autoConfig -match '127\.0\.0\.1|localhost|proxy\.pac') {
        $proxyServer = $null
        $autoConfig  = $null
        $proxyEnable = 0
    }

    [pscustomobject]@{
        AutoConfigURL = $autoConfig
        ProxyEnable   = $proxyEnable
        ProxyServer   = $proxyServer
        ProxyOverride = $cu.ProxyOverride
    } | ConvertTo-Json | Set-Content -Path $FileProxy -Encoding ASCII
}

function Restore-ProxyCfg {
    if (Test-Path $FileProxy) {
        try {
            $b = Get-Content $FileProxy -Raw | ConvertFrom-Json
            if ($b.AutoConfigURL -and $b.AutoConfigURL -notmatch '127\.0\.0\.1|localhost|proxy\.pac') {
                Set-ItemProperty -Path $RegIE -Name AutoConfigURL -Value $b.AutoConfigURL -EA SilentlyContinue
            } else {
                Remove-ItemProperty -Path $RegIE -Name AutoConfigURL -EA SilentlyContinue
            }

            if ($null -ne $b.ProxyEnable -and $b.ProxyServer -notmatch '127\.0\.0\.1|localhost') {
                Set-ItemProperty -Path $RegIE -Name ProxyEnable -Value $b.ProxyEnable -EA SilentlyContinue
            } else {
                Set-ItemProperty -Path $RegIE -Name ProxyEnable -Value 0 -EA SilentlyContinue
            }

            if ($b.ProxyServer -and $b.ProxyServer -notmatch '127\.0\.0\.1|localhost') {
                Set-ItemProperty -Path $RegIE -Name ProxyServer -Value $b.ProxyServer -EA SilentlyContinue
            } else {
                Remove-ItemProperty -Path $RegIE -Name ProxyServer -EA SilentlyContinue
            }

            if ($b.ProxyOverride) {
                Set-ItemProperty -Path $RegIE -Name ProxyOverride -Value $b.ProxyOverride -EA SilentlyContinue
            } else {
                Remove-ItemProperty -Path $RegIE -Name ProxyOverride -EA SilentlyContinue
            }
            Remove-Item $FileProxy -Force -EA SilentlyContinue
        } catch { }
    } else {
        Set-ItemProperty -Path $RegIE -Name ProxyEnable -Value 0 -EA SilentlyContinue
        Remove-ItemProperty -Path $RegIE -Name ProxyServer -EA SilentlyContinue
        Remove-ItemProperty -Path $RegIE -Name AutoConfigURL -EA SilentlyContinue
    }

    # Luon dong bo DefaultConnectionSettings & SavedLegacySettings de Chrome/Edge luon ve Direct
    $regConn = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
    foreach ($val in @('DefaultConnectionSettings', 'SavedLegacySettings')) {
        $bytes = (Get-ItemProperty $regConn -EA SilentlyContinue).$val
        if ($bytes -and $bytes.Length -ge 9) {
            $bytes[8] = 1
            Set-ItemProperty -Path $regConn -Name $val -Value $bytes -EA SilentlyContinue
        }
    }

    try { netsh winhttp reset proxy 2>&1 | Out-Null } catch { }
    Notify-Inet
    if ('NativeCleanup' -as [type]) { [NativeCleanup]::IsActive = $false }
    $script:DaThayDoiProxy = $false
    $script:CongDangDung   = 0
}

function Stop-ProxyMode {
    if ($script:Proxy) { try { $script:Proxy.Stop() } catch { } ; $script:Proxy = $null }
    Restore-Hosts
    Restore-ProxyCfg
}

function Build-PacContent($port) {
    $domainsJs = ($AllGameDomains | ForEach-Object { "`"$_`"" }) -join ', '
    return @"
function FindProxyForURL(url, host) {
  host = host.toLowerCase();
  var d = [$domainsJs];
  for (var i = 0; i < d.length; i++) {
    if (host == d[i] || dnsDomainIs(host, "." + d[i])) return "PROXY 127.0.0.1:$port; DIRECT";
  }
  return "DIRECT";
}
"@
}

function Start-ProxyMode([int]$mode = 2) {
    if (-not ('SplitProxy' -as [type])) {
        try { Add-Type -TypeDefinition $MaProxy -Language CSharp -EA Stop }
        catch { Err "Khong khoi tao duoc proxy: $($_.Exception.Message)"; return $false }
    }
    if ('ConsoleHelper' -as [type]) { [ConsoleHelper]::DisableQuickEdit() }
    if ('NativeCleanup' -as [type]) { [NativeCleanup]::Register() }

    if ($script:Proxy) {
        $script:Proxy.Mode = $mode
        $script:MoTa = "SplitProxy Mode $mode (cong $($script:CongDangDung))"
        return $true
    }

    $px = $null; $cong = 0
    foreach ($p in $CongProxy..($CongProxy + 10)) {
        try {
            $x = New-Object SplitProxy -ArgumentList $p
            $x.Pac  = Build-PacContent $p
            $x.Mode = $mode
            $x.Start()
            $px = $x; $cong = $p; break
        } catch { }
    }
    if (-not $px) { Err 'Khong mo duoc cong proxy nao.'; return $false }

    $script:Proxy        = $px
    $script:CongDangDung = $cong
    Save-ProxyCfg

    # Chi dung AutoConfigURL de phan luong domain Game/Steam qua PAC.
    # ProxyEnable giu = 0 de tranh ep toan bo traffic mang (Facebook, YouTube) vao localhost!
    Set-ItemProperty -Path $RegIE -Name AutoConfigURL -Value "http://127.0.0.1:$cong/proxy.pac" -EA SilentlyContinue
    Set-ItemProperty -Path $RegIE -Name ProxyEnable   -Value 0 -EA SilentlyContinue
    Remove-ItemProperty -Path $RegIE -Name ProxyServer -EA SilentlyContinue
    try { netsh winhttp reset proxy 2>&1 | Out-Null } catch { }
    Notify-Inet

    if ('NativeCleanup' -as [type]) { [NativeCleanup]::IsActive = $true }
    $script:DaThayDoiProxy = $true
    $script:MoTa           = "SplitProxy Mode $mode (cong $cong)"
    Ok "Proxy noi bo dang chay tai cong $cong (PAC loc domain: game + web custom)"

    if ($px.HasDirect443) {
        if (Apply-PubgHosts) {
            Ok 'PUBG Direct Sniper (Port 443 + Hosts) da duoc kich hoat!'
        }
    }
    return $true
}

# ================================================================
#  QUAN LY FILE HOSTS
# ================================================================
function Apply-PubgHosts {
    Save-Hosts
    # Danh sach domain sanh cho, matchmaking entry, xac thuc API va heartbeat Anti-cheat cua PUBG
    $domainsToMap = @(
        'prod-live-front.playbattlegrounds.com',
        'prod-live-entry.playbattlegrounds.com',
        'prod-live-xenuine.playbattlegrounds.com',
        'xenuine.playbattlegrounds.com',
        'api.pubg.com',
        'accounts.pubg.com'
    )
    $linesToAdd = $domainsToMap | ForEach-Object { "127.0.0.1 $_ # SteamAccessFix" }
    try {
        $cur = if (Test-Path $FileHostsSys) { @(Get-Content $FileHostsSys -Encoding ASCII -EA SilentlyContinue) } else { @() }
        $filtered = @($cur | Where-Object { $_ -notmatch '#\s*SteamAccessFix' })
        $newContent = ($filtered + $linesToAdd) -join "`r`n"

        $isRo = $false
        $origAttr = [System.IO.FileAttributes]::Normal
        if (Test-Path $FileHostsSys) {
            $origAttr = [System.IO.File]::GetAttributes($FileHostsSys)
            $isRo = [bool]($origAttr -band [System.IO.FileAttributes]::ReadOnly)
            if ($isRo) {
                [System.IO.File]::SetAttributes($FileHostsSys, $origAttr -band (-bnot [System.IO.FileAttributes]::ReadOnly))
            }
        }

        [IO.File]::WriteAllText($FileHostsSys, $newContent + "`r`n", [Text.Encoding]::ASCII)

        if ($isRo) {
            try { [System.IO.File]::SetAttributes($FileHostsSys, $origAttr) } catch { }
        }

        Flush-DnsCache
        $script:DaThayDoiHosts = $true
        if ('SplitProxy' -as [type]) {
            [SplitProxy]::WarmUpPubgCache()
        }
        return $true
    } catch {
        return $false
    }
}

function Save-Hosts {
    if (Test-Path $FileHosts) { return }
    if (Test-Path $FileHostsSys) {
        Copy-Item -Path $FileHostsSys -Destination $FileHosts -Force -EA SilentlyContinue
        if (Test-Path $FileHosts) {
            try { [System.IO.File]::SetAttributes($FileHosts, [System.IO.FileAttributes]::Normal) } catch { }
        }
    }
}

function Restore-Hosts {
    if (Test-Path $FileHostsSys) {
        try {
            $origAttr = [System.IO.File]::GetAttributes($FileHostsSys)
            $isRo = [bool]($origAttr -band [System.IO.FileAttributes]::ReadOnly)
            if ($isRo) {
                [System.IO.File]::SetAttributes($FileHostsSys, $origAttr -band (-bnot [System.IO.FileAttributes]::ReadOnly))
            }

            $lines = @(Get-Content $FileHostsSys -EA SilentlyContinue | Where-Object { $_ -notmatch '#\s*SteamAccessFix' })
            [IO.File]::WriteAllLines($FileHostsSys, [string[]]$lines, [Text.Encoding]::ASCII)

            if ($isRo) {
                try { [System.IO.File]::SetAttributes($FileHostsSys, $origAttr) } catch { }
            }
            Flush-DnsCache
        } catch { }
    }
    if (Test-Path $FileHosts) {
        try { [System.IO.File]::SetAttributes($FileHosts, [System.IO.FileAttributes]::Normal) } catch { }
        try { [System.IO.File]::Delete($FileHosts) } catch {
            Remove-Item $FileHosts -Force -EA SilentlyContinue
        }
    }
    $script:DaThayDoiHosts = $false
}

# ================================================================
#  TOI UU MANG GAME (FPT / VNPT / VIETTEL)
# ================================================================
function Apply-GamingNetworkTweaks {
    if (Test-Path $FileNetTweaks) { return }
    try {
        $reg   = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
        $props = Get-ItemProperty $reg -EA SilentlyContinue
        [pscustomobject]@{
            NetworkThrottlingIndex = $props.NetworkThrottlingIndex
            SystemResponsiveness   = $props.SystemResponsiveness
        } | ConvertTo-Json | Set-Content -Path $FileNetTweaks -Encoding ASCII

        Set-ItemProperty -Path $reg -Name NetworkThrottlingIndex -Value 0xffffffff -EA SilentlyContinue
        Set-ItemProperty -Path $reg -Name SystemResponsiveness   -Value 0          -EA SilentlyContinue
        netsh int tcp set global autotuninglevel=normal | Out-Null
        $script:DaThayDoiTweaks = $true
    } catch { }
}

function Restore-GamingNetworkTweaks {
    if (Test-Path $FileNetTweaks) {
        try {
            $b   = Get-Content $FileNetTweaks -Raw | ConvertFrom-Json
            $reg = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
            if ($null -ne $b.NetworkThrottlingIndex) { Set-ItemProperty -Path $reg -Name NetworkThrottlingIndex -Value $b.NetworkThrottlingIndex -EA SilentlyContinue }
            if ($null -ne $b.SystemResponsiveness)   { Set-ItemProperty -Path $reg -Name SystemResponsiveness   -Value $b.SystemResponsiveness   -EA SilentlyContinue }
            Remove-Item $FileNetTweaks -Force -EA SilentlyContinue
        } catch { }
    }
    $script:DaThayDoiTweaks = $false
}

function Optimize-Mtu {
    Say ''
    Info 'Dang do MTU toi uu bang goi tin ICMP khong phan manh...'
    $bestMtu = [MtuFinder]::FindBestMtu()
    Ok "MTU toi uu phat hien: $bestMtu (Kich thuoc lon nhat khong bi cat boi nha mang)"

    $adapters = Get-ActiveAdapters
    if (-not (Test-Path $FileMtu)) {
        $backup = @()
        foreach ($a in $adapters) {
            $curMtu = (Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -EA SilentlyContinue).NlMtu
            if ($curMtu) {
                $backup += [pscustomobject]@{ Index = $a.ifIndex; Mtu = $curMtu }
            }
        }
        @($backup) | ConvertTo-Json | Set-Content -Path $FileMtu -Encoding ASCII
    }

    foreach ($a in $adapters) {
        try {
            Set-NetIPInterface -InterfaceIndex $a.ifIndex -NlMtu $bestMtu -EA Stop | Out-Null
        } catch {
            netsh interface ipv4 set subinterface "$($a.ifIndex)" mtu=$bestMtu store=persistent 2>&1 | Out-Null
        }
    }
    $script:DaThayDoiMtu = $true
    $script:CurrentMtu   = $bestMtu
    Ok "Da thiet lap MTU = $bestMtu tren cac card mang dang ket noi!"
    Info "Goi tin game se khong bi phan manh tren router, toi uu hoa hitreg va ping."
}

function Restore-Mtu {
    if (Test-Path $FileMtu) {
        try {
            $items = Get-Content $FileMtu -Raw | ConvertFrom-Json
            foreach ($item in @($items)) {
                try {
                    Set-NetIPInterface -InterfaceIndex $item.Index -NlMtu $item.Mtu -EA Stop | Out-Null
                } catch {
                    netsh interface ipv4 set subinterface "$($item.Index)" mtu=$item.Mtu store=persistent 2>&1 | Out-Null
                }
            }
            Remove-Item $FileMtu -Force -EA SilentlyContinue
        } catch { }
    }
    $script:DaThayDoiMtu = $false
    $script:CurrentMtu   = 0
}

function Minimize-ToTray {
    Add-Type -AssemblyName System.Windows.Forms -EA SilentlyContinue
    Add-Type -AssemblyName System.Drawing -EA SilentlyContinue

    $ni = New-Object System.Windows.Forms.NotifyIcon
    $ni.Text = "AccessFix Custom - Dang chay ngam"
    $ni.Icon = [System.Drawing.SystemIcons]::Shield
    $ni.Visible = $true

    $cm = New-Object System.Windows.Forms.ContextMenu
    $itemOpen = $cm.MenuItems.Add('Mo cua so AccessFix Custom')
    $itemExit = $cm.MenuItems.Add('Thoat & Khoi phuc cai dat')
    $ni.ContextMenu = $cm

    $script:TrayShouldRestore = $false
    $script:TrayShouldExit    = $false

    $actionOpen = {
        $script:TrayShouldRestore = $true
    }
    $actionExit = {
        $script:TrayShouldExit = $true
    }

    $itemOpen.add_Click($actionOpen)
    $itemExit.add_Click($actionExit)
    $ni.add_DoubleClick($actionOpen)

    # An cua so console
    [ConsoleHelper]::HideConsole()

    # Thong bao tren khay he thong
    $ni.ShowBalloonTip(2000, "AccessFix Custom v$script:AppVersion", "Tool dang chay ngam giup vuot chan web.`nClick dup vao bieu tuong de mo lai.", [System.Windows.Forms.ToolTipIcon]::Info)

    while (-not $script:TrayShouldRestore -and -not $script:TrayShouldExit) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 150
    }

    $ni.Visible = $false
    $ni.Dispose()

    # Hien lai cua so console
    [ConsoleHelper]::ShowConsole()

    if ($script:TrayShouldExit) {
        return 'exit'
    }
    return 'restore'
}

function Restore-All {
    Say ''
    Info 'Dang khoi phuc toan bo cai dat ve trang thai goc...'
    Stop-ProxyMode
    Restore-GamingNetworkTweaks
    Restore-Mtu
    Restore-Hosts
    Restore-Dns
    Ok 'He thong da duoc khoi phuc sach se.'
    Show-Dns
}

# ================================================================
#  CAP NHAT GITHUB
# ================================================================
function Update-FromGitHub {
    # [Custom] Ban da chinh sua them LinkedIn: tat tu cap nhat de khong bi ghi de mat phan custom
    Warn 'Ban custom (LinkedIn, Quora) da tat tu cap nhat. Muon len ban moi thi tai lai va them domain custom bang tay.'
    return
    if (-not $env:SELF -or -not (Test-Path $env:SELF)) { return }
    try {
        Info 'Dang kiem tra va tai ban cap nhat...'
        $tNow = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $tmp = Join-Path $env:TEMP ("SAF_update_" + [guid]::NewGuid().ToString('N') + ".cmd")
        $urls = @(
            "https://gitlab.com/$($script:GitHubRepo)/-/raw/main/SteamAccessFix.cmd?t=$tNow",
            "https://raw.githubusercontent.com/$($script:GitHubRepo)/main/SteamAccessFix.cmd?t=$tNow"
        )
        $downloaded = $false
        foreach ($u in $urls) {
            try {
                Invoke-WebRequest -Uri $u -Headers @{ 'Cache-Control' = 'no-cache' } -OutFile $tmp -TimeoutSec 12 -EA Stop
                $downloaded = $true
                break
            } catch { }
        }
        if (-not $downloaded) { throw "Khong the ket noi toi may chu cap nhat." }
        $content = [IO.File]::ReadAllText($tmp, [Text.Encoding]::UTF8)
        if ($content.Contains('#PSBEGIN#') -and $content.Length -gt 2000) {
            Ok 'Xac thuc goi cap nhat hop le.'
            Ok "Da ghi de cap nhat vao: $env:SELF"
            Copy-Item -Path $tmp -Destination $env:SELF -Force
            Remove-Item $tmp -Force -EA SilentlyContinue
            Info 'Dang khoi dong lai phien ban moi...'
            Start-Sleep -Milliseconds 600
            Start-Process -FilePath $env:SELF -WorkingDirectory (Split-Path $env:SELF)
            exit
        } else {
            Err 'Goi cap nhat khong hop le. Da huy.'
            Remove-Item $tmp -Force -EA SilentlyContinue
        }
    } catch {
        Err "Loi khi tai cap nhat: $($_.Exception.Message)"
    }
}

# ================================================================
#  MAN HINH TRANG THAI & PHIM TAT RUNTIME
# ================================================================
function Show-DnsMenu {
    $pingData = @()
    foreach ($p in $script:DnsPresets) {
        $pingData += "$($p.Id)|$($p.Name)|$($p.Short)|$($p.P1)|$($p.P2)"
    }

    $measureAll = {
        $map = @{}
        $fastId = -1
        $minP = 999999
        try {
            $res = [DnsPinger]::TestAll([string[]]$pingData)
            foreach ($r in $res) {
                $map[$r.Id] = $r.PingMs
                if ($r.PingMs -ge 0 -and $r.PingMs -lt $minP) {
                    $minP = $r.PingMs
                    $fastId = $r.Id
                }
            }
        } catch { }
        return @{ Map = $map; FastestId = $fastId; MinPing = $minP }
    }

    # Tu dong do ping tat ca 10 DNS ngay khi mo menu (~70ms sieu toc)
    $testResult = & $measureAll

    while ($true) {
        try { Clear-Host } catch { }
        Say ''
        Say "  [>] BANG DO PING & LUA CHON DNS CHO GAME" 'Cyan'
        Sep
        Say '  STT   Nha cung cap      May chu (IPv4)   Ping        Trang thai' 'DarkCyan'

        foreach ($p in $script:DnsPresets) {
            $idStr   = "[$($p.Id)]".PadRight(6)
            $nameStr = $p.Name.PadRight(18)
            $ipStr   = $p.P1.PadRight(17)

            Write-Host "  $idStr$nameStr$ipStr" -ForegroundColor White -NoNewline

            $ping = if ($testResult.Map.ContainsKey($p.Id)) { $testResult.Map[$p.Id] } else { -1 }
            if ($ping -ge 0) {
                $color = if ($ping -lt 40) { 'Green' } elseif ($ping -lt 80) { 'Yellow' } else { 'DarkYellow' }
                Write-Host ("$ping ms").PadRight(12) -ForegroundColor $color -NoNewline
            } else {
                Write-Host ('Timeout'.PadRight(12)) -ForegroundColor DarkGray -NoNewline
            }

            $isCurrent = ($script:CurrentDnsShort -eq $p.Short)
            $isFastest = ($p.Id -eq $testResult.FastestId)

            if ($isCurrent -and $isFastest) {
                Write-Host '[Dang dung | Nhanh nhat]' -ForegroundColor Green
            } elseif ($isCurrent) {
                Write-Host '[Dang dung]' -ForegroundColor Green
            } elseif ($isFastest) {
                Write-Host '[Nhanh nhat]' -ForegroundColor Cyan
            } else {
                Write-Host ''
            }
        }

        Write-Host '  [0]   DNS goc he thong  (Khong doi DNS card mang)    ' -ForegroundColor White -NoNewline
        if ($script:DnsMode -eq 'Keep') {
            Write-Host '[Dang dung]' -ForegroundColor Green
        } else {
            Write-Host ''
        }

        Sep
        Say '  [1-10]   Chon DNS theo so thu tu' 'White'
        Say '  [0]      Tra ve DNS goc cua he thong (khong can thiep DNS card mang)' 'White'
        if ($testResult.FastestId -gt 0) {
            Say "  [F]      Chon nhanh DNS co Ping thap nhat ($($testResult.MinPing) ms)" 'Yellow'
        }
        Say '  [R]      Do lai Ping (Refresh)' 'Cyan'
        Say '  [Enter]  Quay lai menu chinh' 'DarkGray'
        Sep
        Say ''
        Write-Host '  Lua chon [1-10 / 0 / F / R / Enter]: ' -ForegroundColor Yellow -NoNewline
        $ans = Read-Host

        if ([string]::IsNullOrWhiteSpace($ans)) {
            break
        }
        elseif ($ans -eq '0') {
            Say ''
            Info 'Dang tra lai DNS goc cua he thong...'
            Restore-Dns
            $script:DnsMode = 'Keep'
            $script:CurrentDnsName = 'Giu nguyen DNS he thong'
            $script:CurrentDnsShort = 'He thong'
            $script:DaThayDoiDns = $false
            Ok 'Da tra ve DNS he thong goc (Tool se GIU NGUYEN DNS card mang)!'
            Start-Sleep -Milliseconds 400
            break
        }
        elseif ($ans -match '^[rR]') {
            $testResult = & $measureAll
        }
        elseif ($ans -match '^[fF]') {
            if ($testResult.FastestId -gt 0) {
                $preset = $script:DnsPresets | Where-Object { $_.Id -eq $testResult.FastestId } | Select-Object -First 1
                if ($preset) {
                    Say ''
                    Info "Dang gan DNS nhanh nhat: $($preset.Name) ($($preset.P1), $($preset.P2))..."
                    if (Set-CustomDns $preset.Name $preset.Short @($preset.P1, $preset.P2)) {
                        Ok "Da chuyen sang: $($preset.Name) ($($testResult.MinPing) ms)!"
                    } else {
                        Warn "Khong the gan DNS tren mot so card mang."
                    }
                    Start-Sleep -Milliseconds 400
                    break
                }
            }
        }
        else {
            $num = 0
            if ([int]::TryParse($ans, [ref]$num) -and $num -ge 1 -and $num -le $script:DnsPresets.Count) {
                $preset = $script:DnsPresets | Where-Object { $_.Id -eq $num } | Select-Object -First 1
                if ($preset) {
                    Say ''
                    Info "Dang gan $($preset.Name) ($($preset.P1), $($preset.P2))..."
                    if (Set-CustomDns $preset.Name $preset.Short @($preset.P1, $preset.P2)) {
                        Ok "Da chuyen sang: $($preset.Name)!"
                    } else {
                        Warn "Khong the gan DNS tren mot so card mang."
                    }
                    Start-Sleep -Milliseconds 400
                    break
                }
            }
        }
    }
}

function Show-StatusBar {
    Say ''
    Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
    Sep

    # [Custom] Ban custom da tat cap nhat nen an thong bao "Bam U de cap nhat"
    $rem = $null
    if ($rem) {
        $isNew = $false
        try { if ([version]$rem -gt [version]$script:AppVersion) { $isNew = $true } } catch { if ($rem -ne $script:AppVersion) { $isNew = $true } }
        if ($isNew) {
            Say "  [*] CO PHIEN BAN MOI: v$rem (Bam U de cap nhat)" 'Yellow'
            Sep
        }
    }

    Say '  [*] CHE DO DANG HOAT DONG:' 'Green'
    if ($script:CurrentLevel -eq 2) {
        Say "      > Che do:  Cap do 2 - SplitProxy SNI (Port $($script:CongDangDung))" 'Green'
        Say "      > Web:     $($CustomSites -join ', ')  [vuot chan]" 'Green'
    } else {
        Say '      > Che do:  Cap do 1 - DNS Only (Khong dung Proxy)' 'Green'
        Say "      > Web:     $($CustomSites -join ', ')  [can bam 2]" 'Yellow'
    }
    if ($script:DnsMode -eq 'Keep') {
        Say '      > DNS:     Giu nguyen DNS he thong' 'Yellow'
    } else {
        Say "      > DNS:     $($script:CurrentDnsName) ($($script:CurrentDnsServers -join ', '))" 'White'
    }
    if ($script:DaThayDoiMtu) {
        Say "      > MTU:     $($script:CurrentMtu) (Toi uu PPPoE chong phan manh)" 'Cyan'
    }
    # [Custom] Dong Auto-Hook game: an cho gon
    if ($script:DaThayDoiHosts) {
        Say '      > PUBG Sniper: Kich hoat Port 443 + Hosts (chong loi Server Busy & mat ket noi)' 'Green'
    }

    if ($script:CurrentLevel -eq 2) {
        Sep
        Say '  Luu y:' 'Cyan'
        Say '  - GIU CUA SO NAY MO khi dang dung web can vuot chan (hoac bam M de thu nho).' 'Yellow'
    }

    Sep
    Say '  Phim tat:' 'DarkCyan'
    if ($script:CurrentLevel -eq 1) {
        Write-Host '  [1]      Cap do 1 (Chi DNS)            ' -ForegroundColor White -NoNewline
        Write-Host '[Dang dung]' -ForegroundColor Green
        Say        '  [2]      Cap do 2 (SplitProxy)' 'White'
    } else {
        Say        '  [1]      Cap do 1 (Chi DNS)' 'White'
        Write-Host '  [2]      Cap do 2 (SplitProxy)         ' -ForegroundColor White -NoNewline
        Write-Host '[Dang dung]' -ForegroundColor Green
    }
    Write-Host '  [D]      Doi DNS: Chon / Test Ping     ' -ForegroundColor White -NoNewline
    if ($script:DnsMode -eq 'Keep') {
        Write-Host '[He thong]' -ForegroundColor Yellow
    } else {
        Write-Host "[$($script:CurrentDnsShort)]" -ForegroundColor Cyan
    }

    Write-Host '  [T]      Toi uu MTU duong truyen       ' -ForegroundColor White -NoNewline
    if ($script:DaThayDoiMtu) { Write-Host "[$($script:CurrentMtu)]" -ForegroundColor Green }
    else                      { Write-Host '[Mac dinh]' -ForegroundColor DarkGray }

    Say        '  [M]      Thu nho xuong khay he thong   [Tray]' 'White'

    Write-Host '  [A]      Khoi dong cung Windows        ' -ForegroundColor White -NoNewline
    if (Test-Autostart) { Write-Host '[Bat]' -ForegroundColor Green }
    else                { Write-Host '[Tat]' -ForegroundColor DarkGray }

    Say '  [K]      Luu DNS vinh vien va Thoat' 'White'
    Say '  [R]      Khoi phuc mang goc va Thoat' 'Yellow'
    Say '  [Enter]  Thoat' 'DarkGray'
    Sep
    Say ''
}

# ================================================================
#  DON DEP & TU PHUC HOI SU CO (SELF-HEALING)
# ================================================================
function Sanitize-Environment {
    $hasIssue = $false

    # 1. Kiem tra Registry ton dong proxy cu (127.0.0.1 hoac port 18080)
    $cu = Get-ItemProperty $RegIE -EA SilentlyContinue
    if ($cu.ProxyServer -match '127\.0\.0\.1|18080' -or $cu.AutoConfigURL -match '127\.0\.0\.1|18080|proxy\.pac') {
        $hasIssue = $true
    }

    # 2. Kiem tra WinHTTP
    $winhttp = netsh winhttp show proxy 2>&1 | Out-String
    if ($winhttp -match '127\.0\.0\.1|18080') {
        $hasIssue = $true
    }

    # 3. Kiem tra file hosts con sot lai domain PUBG cua SAF khong
    if (Test-Path $FileHostsSys) {
        $hLines = Get-Content $FileHostsSys -EA SilentlyContinue
        if ($hLines -match '#\s*SteamAccessFix') {
            $hasIssue = $true
        }
    }

    # 4. Kiem tra file backup cu bi nhiem doc
    if (Test-Path $FileProxy) {
        try {
            $b = Get-Content $FileProxy -Raw | ConvertFrom-Json
            if ($b.ProxyServer -match '127\.0\.0\.1|18080' -or $b.AutoConfigURL -match '127\.0\.0\.1|18080') {
                $hasIssue = $true
                Remove-Item $FileProxy -Force -EA SilentlyContinue
            }
        } catch { }
    }

    if ($hasIssue -or (Test-Path $FileDns) -or (Test-Path $FileProxy) -or (Test-Path $FileHosts) -or (Test-Path $FileNetTweaks) -or (Test-Path $FileMtu)) {
        Warn 'Phat hien cai dat mang chua dong dung cach (hoac ton dong tu ban cu) - dang tu dong khoi phuc...'
        Restore-All
        Start-Sleep -Milliseconds 600
        Ok 'He thong da duoc lam sach va san sang!'
        Say ''
    }
}

# ================================================================
#  CHE DO CHAY NGAM + TU KHOI DONG CUNG WINDOWS
#  SteamAccessFix.cmd /install | /uninstall | /stop | /silent | /status
# ================================================================
function Write-Log($m) {
    try {
        if ((Test-Path $FileLog) -and ((Get-Item $FileLog).Length -gt 200KB)) { Remove-Item $FileLog -Force -EA SilentlyContinue }
        Add-Content -Path $FileLog -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $m) -Encoding ASCII
    } catch { }
}

function Test-Autostart {
    try { return [bool](Get-ScheduledTask -TaskName $TenTask -ErrorAction SilentlyContinue) } catch { return $false }
}

function Install-Autostart {
    try {
        # Luu tru ban sao DNS goc vinh vien truoc khi bat tu khoi dong de [R] luon tra ve duoc
        Save-Dns
        if ((Test-Path $FileDns) -and -not (Test-Path $FileDnsKeep)) {
            Copy-Item $FileDns $FileDnsKeep -Force -EA SilentlyContinue
        }

        # Copy file ve ProgramData de tac vu khong phu thuoc vi tri file (Downloads, Desktop...)
        $dst = Join-Path $ThuMucLuu 'SteamAccessFix.cmd'
        $src = $env:SELF
        if ($src -and (Test-Path $src)) {
            if ((Resolve-Path $src).Path -ne $dst) { Copy-Item -Path $src -Destination $dst -Force }
        } else {
            try {
                Invoke-WebRequest -Uri "https://gitlab.com/$($script:GitHubRepo)/-/raw/main/SteamAccessFix.cmd" -OutFile $dst -TimeoutSec 15 -EA Stop
            } catch {
                Invoke-WebRequest -Uri "https://raw.githubusercontent.com/$($script:GitHubRepo)/main/SteamAccessFix.cmd" -OutFile $dst -TimeoutSec 20 -EA Stop
            }
        }

        $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$env:SELF=''__DST__''; $env:SAF_ARGS=''/silent''; Invoke-Expression ([System.IO.File]::ReadAllText($env:SELF, [System.Text.Encoding]::UTF8))"'
        $arg = $arg.Replace('__DST__', $dst)

        $user = "$env:USERDOMAIN\$env:USERNAME"
        $act  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
        $trg  = New-ScheduledTaskTrigger -AtLogOn -User $user
        $trg.Delay = 'PT10S'
        $pri  = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
        $set  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero)
        Register-ScheduledTask -TaskName $TenTask -Action $act -Trigger $trg -Principal $pri -Settings $set -Description 'SteamAccessFix - chay ngam cung Windows' -Force -ErrorAction Stop | Out-Null
        Ok 'Da BAT tu khoi dong ngam cung Windows (khong hien cua so, khong hoi UAC).'
        return $true
    } catch {
        Err "Khong tao duoc tac vu tu khoi dong: $($_.Exception.Message)"
        return $false
    }
}

function Uninstall-Autostart {
    try {
        Unregister-ScheduledTask -TaskName $TenTask -Confirm:$false -ErrorAction SilentlyContinue
        $dst = Join-Path $ThuMucLuu 'SteamAccessFix.cmd'
        if (Test-Path $dst) { Remove-Item $dst -Force -EA SilentlyContinue }
        Ok 'Da TAT tu khoi dong ngam.'
    } catch {
        Err "Khong go duoc tac vu: $($_.Exception.Message)"
    }
}

# --- Chi cho phep 1 phien chay cung luc (tranh chay song song) ---
$script:Mutex = $null
$script:MutexOwned = $false

function Acquire-Instance {
    if ($script:MutexOwned) { return $true }
    if (-not $script:Mutex) {
        try { $script:Mutex = New-Object System.Threading.Mutex($false, 'Global\SteamAccessFix_Instance') }
        catch { return $true }
    }
    try {
        $acquired = $script:Mutex.WaitOne(0)
        if ($acquired) { $script:MutexOwned = $true }
        return $acquired
    }
    catch [System.Threading.AbandonedMutexException] {
        $script:MutexOwned = $true
        return $true
    }
    catch {
        return $true
    }
}

function Release-Instance {
    if ($script:Mutex -and $script:MutexOwned) {
        try { $script:Mutex.ReleaseMutex() } catch { }
        $script:MutexOwned = $false
    }
    if (Test-Path $FileInst) {
        try { [System.IO.File]::SetAttributes($FileInst, [System.IO.FileAttributes]::Normal) } catch { }
        Remove-Item $FileInst -Force -EA SilentlyContinue
    }
}

# Gui lenh dung cho ban chay ngam (qua stop.flag), doi toi khi no nha khoa -> ta giu khoa
function Stop-Background {
    New-Item -ItemType File -Force -Path $FileStop | Out-Null
    $free = $false
    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Milliseconds 500
        if (Acquire-Instance) { $free = $true; break }
    }
    # Fallback neu qua 15 giay chua dung
    if (-not $free) {
        try { Stop-ScheduledTask -TaskName $TenTask -EA SilentlyContinue } catch { }
        Start-Sleep -Seconds 1
        if (Acquire-Instance) { $free = $true }
    }
    Remove-Item $FileStop -Force -EA SilentlyContinue
    return $free
}

function Hide-Console {
    try {
        if (-not ('Win.Con' -as [type])) {
            Add-Type -Namespace Win -Name Con -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int n);' -EA SilentlyContinue
        }
        $h = [Win.Con]::GetConsoleWindow()
        if ($h -ne [IntPtr]::Zero) { [void][Win.Con]::ShowWindow($h, 0) }
    } catch { }
}

function Run-Silent {
    Hide-Console
    Remove-Item $FileStop -Force -EA SilentlyContinue
    Write-Log "Khoi dong che do ngam v$script:AppVersion"

    # Cho card mang ket noi xong (toi da 15 giay sau khoi dong)
    for ($i = 0; $i -lt 15; $i++) {
        if (Get-NetAdapter -EA SilentlyContinue | Where-Object Status -eq 'Up') { break }
        Start-Sleep -Seconds 1
    }

    # Tu chua lanh sau khi tat may dot ngot / mat dien
    Sanitize-Environment

    if (Set-GoogleDns) { Write-Log 'DNS Cloudflare OK' } else { Write-Log 'DNS Cloudflare: mot so card mang khong dat duoc' }
    Apply-GamingNetworkTweaks
    if (Start-ProxyMode 2) { $script:CurrentLevel = 2; Write-Log 'SplitProxy Cap do 2 dang chay' }
    else                   { $script:CurrentLevel = 1; Write-Log 'Khong mo duoc proxy - chi chay DNS Google' }
    if ('GameWatcher' -as [type]) { [GameWatcher]::Start() }

    # Cho lenh dung (tu [1]/[X] o cua so khac hoac /stop)
    while (-not (Test-Path $FileStop)) { Start-Sleep -Seconds 2 }
    Write-Log 'Nhan lenh dung - dang khoi phuc he thong'
}

# ================================================================
#  CHUONG TRINH CHINH
# ================================================================
$script:Silent = Has-Arg 'silent'

# --- Lenh tro giup /? ---
if (Has-Arg 'help' -or Has-Arg '\?' -or Has-Arg 'h') {
    Ve-Khung "ACCESS FIX CUSTOM v$script:AppVersion - HUONG DAN THAM SO DONG LENH"
    Say '  Cac tham so dong lenh ho tro:' 'Cyan'
    Say '    /install    - Cai dat tu khoi dong ngam cung Windows (khong hien cua so)' 'White'
    Say '    /uninstall  - Go bo tu khoi dong ngam va dung ban ngam dang chay' 'White'
    Say '    /stop       - Dung ban chay ngam va khoi phuc cai dat mang' 'White'
    Say '    /status     - Kiem tra trang thai ban chay ngam va thong tin DNS' 'White'
    Say '    /silent     - Chay che do ngam (dung cho Task Scheduler)' 'White'
    Say '    /nodns      - Giu nguyen DNS he thong (khong doi DNS, an toan cho IP tinh)' 'White'
    Sep
    Say ''
    Write-Host '  Nhan [Enter] de dong...' -ForegroundColor DarkGray -NoNewline
    [void](Read-Host)
    return
}

# --- Lenh kiem tra trang thai /status ---
if (Has-Arg 'status') {
    Ve-Khung "ACCESS FIX CUSTOM v$script:AppVersion - KIEM TRA TRANG THAI HE THONG"
    if (Test-Autostart) { Ok 'Tu khoi dong ngam: DANG BAT' } else { Info 'Tu khoi dong ngam: DANG TAT' }
    if (-not (Acquire-Instance)) {
        $inst = "$(Get-Content $FileInst -Raw -EA SilentlyContinue)".Trim()
        Ok "Tien trinh dang chay: CO ($inst)"
    } else {
        Release-Instance
        Info 'Tien trinh dang chay: KHONG'
    }
    Show-Dns
    Sep
    Say ''
    Write-Host '  Nhan [Enter] de dong...' -ForegroundColor DarkGray -NoNewline
    [void](Read-Host)
    return
}

# --- Lenh quan ly (khong can giu khoa phien) ---
if (Has-Arg 'uninstall') {
    Ve-Khung "ACCESS FIX CUSTOM v$script:AppVersion - TAT TU KHOI DONG NGAM"
    Uninstall-Autostart
    if (-not (Acquire-Instance)) {
        Info 'Dang dung ban chay ngam dang chay...'
        if (Stop-Background) { Release-Instance; Ok 'Da dung ban chay ngam va khoi phuc he thong.' }
    }
    Sep
    Say ''
    Write-Host '  Nhan [Enter] de dong...' -ForegroundColor DarkGray -NoNewline
    [void](Read-Host)
    return
}
if (Has-Arg 'install') {
    Ve-Khung "ACCESS FIX CUSTOM v$script:AppVersion - BAT TU KHOI DONG NGAM"
    if (Install-Autostart) {
        Say ''
        Info 'Ban co the khoi dong lai may de tu kich hoat, hoac mo file de dung ngay.'
    }
    Sep
    Say ''
    Write-Host '  Nhan [Enter] de dong...' -ForegroundColor DarkGray -NoNewline
    [void](Read-Host)
    return
}
if (Has-Arg 'stop') {
    Ve-Khung "ACCESS FIX CUSTOM v$script:AppVersion - DUNG BAN CHAY NGAM"
    if (Acquire-Instance) {
        Release-Instance
        Warn 'Khong co ban chay ngam nao dang chay.'
    } elseif (Stop-Background) {
        Release-Instance
        Ok 'Da dung ban chay ngam va khoi phuc he thong.'
    } else {
        Err 'Khong dung duoc (co the dang mo o cua so khac).'
    }
    Sep
    Say ''
    Write-Host '  Nhan [Enter] de dong...' -ForegroundColor DarkGray -NoNewline
    [void](Read-Host)
    return
}

# --- Kiem tra phien dang chay (PHAI lam truoc Sanitize de khong pha cai dat cua ban ngam) ---
if (-not (Acquire-Instance)) {
    if ($script:Silent) { return }

    $mode = "$(Get-Content $FileInst -Raw -EA SilentlyContinue)".Trim()
    if ($mode -ne 'silent') {
        Say ''
        Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
        Sep
        Warn 'AccessFix hien dang chay o mot cua so khac tren may.'
        Info 'Hay dong cua so dang chay (bam [Q] hoac [Enter] tai cua so do) roi mo lai.'
        Sep
        Say ''
        Write-Host '  Nhan [Enter] de thoat... ' -ForegroundColor DarkGray -NoNewline
        [void](Read-Host)
        return
    }

    Say ''
    Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
    Sep
    Warn 'Dang co ban chay ngam (tu khoi dong cung Windows).'
    Info 'Mang da duoc toi uu san, ban co the dung ngay ma khong can mo them cua so nay.'
    Sep
    Say '  Lua chon xu ly:' 'DarkCyan'
    Say '    [Enter]  Thoat, de ban chay ngam tiep tuc hoat dong' 'White'
    Say '    [1]      Dung ban chay ngam va chuyen sang chay o cua so nay' 'White'
    Say '    [X]      Dung ban chay ngam va TAT tu khoi dong ngam' 'White'
    Sep
    Say ''
    Write-Host '  Lua chon [Enter / 1 / X]: ' -ForegroundColor Yellow -NoNewline
    $r = Read-Host

    if ($r -match '^[xX]') {
        Uninstall-Autostart
        Info 'Dang dung ban chay ngam...'
        if (Stop-Background) { Release-Instance; Ok 'Da dung. He thong da duoc khoi phuc.' }
        else                 { Err 'Khong dung duoc ban chay ngam.' }
        Start-Sleep -Seconds 2
        return
    }
    elseif ($r -eq '1') {
        Info 'Dang dung ban chay ngam...'
        if (-not (Stop-Background)) { Err 'Khong dung duoc ban chay ngam.'; Start-Sleep -Seconds 2; return }
        Ok 'Da dung ban chay ngam. Dang chay o cua so nay...'
    }
    else { return }
}
if ($script:Silent) { Set-Content -Path $FileInst -Value 'silent' -Encoding ASCII }
else                { Set-Content -Path $FileInst -Value 'window' -Encoding ASCII }

try {
    # Khoi tao C# va dang ky Exit Handler som de bat tat ca cac su kien dong cua so [X]
    if (-not ('NativeCleanup' -as [type])) {
        try { Add-Type -TypeDefinition $MaProxy -Language CSharp -EA Stop } catch { }
    }
    if ('NativeCleanup' -as [type]) {
        [NativeCleanup]::Register()
    }
    if ('ConsoleHelper' -as [type]) {
        [ConsoleHelper]::DisableQuickEdit()
    }
    if ('GameWatcher' -as [type]) {
        [GameWatcher]::Start()
    }
    if ('FastUpdater' -as [type]) {
        [FastUpdater]::CheckAsync($script:GitHubRepo)
    }

    if ($script:Silent) {
        Run-Silent
    }
    else {
        Say ''
        Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
        Sep

        # Don dep phien truoc neu bi tat dot ngot
        Sanitize-Environment

        # 1. Thiet lap DNS theo che do
        if ($script:DnsMode -eq 'Cloudflare') {
            Info 'Dang gan DNS Cloudflare (1.1.1.1)...'
            if (Set-GoogleDns) { Ok 'Da gan DNS Cloudflare: 1.1.1.1  &  1.0.0.1' }
            else               { Warn 'Mot so card mang khong nhan DNS Cloudflare (xem DNS hien tai ben duoi).' }
        } else {
            Info 'Che do DNS: GIU NGUYEN DNS he thong (khong can thiep DNS card mang).'
        }
        Show-Dns

        # 2. Toi uu Network Stack cho Game
        Info 'Dang ap dung toi uu network stack...'
        Apply-GamingNetworkTweaks
        Ok 'Da toi uu NetworkThrottling & TCP AutoTuning.'

        # 3. Kich hoat SplitProxy Mode 2
        Info 'Dang kich hoat SplitProxy (Phan manh TLS SNI Mode 2)...'
        if (Start-ProxyMode 2) {
            $script:CurrentLevel = 2
            Ok 'Cap do 2 thanh cong! SplitProxy vuot qua bo loc SNI.'
        } else {
            $script:CurrentLevel = 1
            Warn 'Khong khoi dong duoc proxy. Dang chay Cap do 1 (DNS Google).'
        }

        Start-Sleep -Milliseconds 150
        try { Clear-Host } catch { }
        Show-StatusBar

        while ($true) {
            Write-Host '  Lua chon [1 / 2 / D / T / M / A / K / R / Enter]: ' -ForegroundColor Yellow -NoNewline
            $k = Read-Host

            if ($k -match '^[uU]') {
                Say ''
                Update-FromGitHub
                Start-Sleep -Milliseconds 200
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -match '^[dD]') {
                Show-DnsMenu
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -match '^[tT]') {
                Optimize-Mtu
                Start-Sleep -Milliseconds 1200
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -match '^[mM]') {
                $action = Minimize-ToTray
                if ($action -eq 'exit') { break }
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -eq '2') {
                Say ''
                Info 'Dang kich hoat Cap do 2 (SplitProxy)...'
                if (Start-ProxyMode 2) {
                    $script:CurrentLevel = 2
                    Ok 'SplitProxy dang hoat dong!'
                } else {
                    Err 'Khong khoi dong duoc SplitProxy.'
                }
                Start-Sleep -Milliseconds 200
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -eq '1') {
                Say ''
                Info "Dang chuyen ve Cap do 1 ($($script:CurrentDnsName) only)..."
                Stop-ProxyMode
                $script:CurrentLevel = 1
                $script:MoTa = "$($script:CurrentDnsName) + Toi uu Ping Game"
                Ok "Da tat Proxy. Dang chay Cap do 1 ($($script:CurrentDnsName))."
                Start-Sleep -Milliseconds 200
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -match '^[kK]') {
                try { Clear-Host } catch { }
                Say ''
                Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
                Sep
                Info "Da chon giu lai $($script:CurrentDnsName) va toi uu Ping."
                # Luu ban sao DNS goc (chi lan dau) de [R] van tra lai duoc sau nay
                if ((Test-Path $FileDns) -and -not (Test-Path $FileDnsKeep)) { Copy-Item $FileDns $FileDnsKeep -Force -EA SilentlyContinue }
                $script:DaThayDoiDns    = $false
                $script:DaThayDoiTweaks = $false
                if (Test-Path $FileDns)       { Remove-Item $FileDns       -Force -EA SilentlyContinue }
                if (Test-Path $FileNetTweaks) { Remove-Item $FileNetTweaks -Force -EA SilentlyContinue }
                Stop-ProxyMode
                Ok "$($script:CurrentDnsName) & toi uu Ping da duoc luu vinh vien tren may."
                Show-Dns
                Info 'Muon tra DNS ve nhu ban dau: mo lai tool va bam [R].'
                Sep
                break
            }
            elseif ($k -match '^[rR]') {
                try { Clear-Host } catch { }
                Say ''
                Say "  [>] ACCESS FIX CUSTOM v$script:AppVersion" 'Cyan'
                Sep
                Info 'Dang khoi phuc mang he thong sach 100% va go bo moi thiet lap...'
                Restore-All
                if (Test-Path $FileDnsKeep) {
                    Info 'Dang tra DNS ve gia tri goc (luu truoc khi bam [K])...'
                    Restore-Dns $FileDnsKeep
                    Show-Dns
                }
                # Chi xoa file backup/trang thai; GIU lai ban chay ngam (SteamAccessFix.cmd) neu dang bat
                foreach ($f in @($FileDns, $FileProxy, $FileHosts, $FileNetTweaks, $FileMtu, $FileDnsKeep)) {
                    if (Test-Path $f) {
                        try { [System.IO.File]::SetAttributes($f, [System.IO.FileAttributes]::Normal) } catch { }
                        Remove-Item $f -Force -EA SilentlyContinue
                    }
                }
                Ok 'He thong da duoc khoi phuc sach se hoan toan!'
                Sep
                Start-Sleep -Seconds 1
                break
            }
            elseif ($k -match '^[aA]') {
                Say ''
                if (Test-Autostart) { Uninstall-Autostart } else { [void](Install-Autostart) }
                Start-Sleep -Milliseconds 200
                try { Clear-Host } catch { }
                Show-StatusBar
            }
            elseif ($k -match '^[qQ]' -or [string]::IsNullOrWhiteSpace($k)) {
                break
            }
            else {
                try { Clear-Host } catch { }
                Show-StatusBar
            }
        }
    }
}
finally {
    if ('GameWatcher' -as [type]) {
        [GameWatcher]::Stop()
    }
    if ($script:DaThayDoiDns -or $script:DaThayDoiProxy -or $script:DaThayDoiHosts -or $script:DaThayDoiTweaks -or $script:DaThayDoiMtu) {
        Say ''
        Sep
        Restore-All
        Start-Sleep -Seconds 1
    }
    if ('NativeCleanup' -as [type]) {
        [NativeCleanup]::Unregister()
    }
    Release-Instance
}
